#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <event2/event.h>
#include "async.h"

#define MAX_TABLE_SIZE 10007

#define DELETE_ENTRY(hash_table, i) do {		\
    if ((hash_table)[(i)] != NULL) {			\
      (hash_table)[(i)]->destruct((hash_table)[(i)]);	\
      (hash_table)[(i)] = NULL;				\
    }							\
  } while (0)

extern void _main(void);

struct do_accept_args {
  struct event *e;
  int socket;
  void (*destruct)(struct do_accept_args *);
} *do_accept_hash_table[MAX_TABLE_SIZE];

struct do_read_args {
  struct event *e;
  struct client_state *s;
  void (*destruct)(struct do_read_args *);
} *do_read_hash_table[MAX_TABLE_SIZE];

struct do_write_args {
  struct event *e;
  struct client_state *s;
  void (*destruct)(struct do_write_args *);
} *do_write_hash_table[MAX_TABLE_SIZE];

struct event_base *b;
struct event *sigint_event;

int do_accept_hash(int socket) {
  int result = 1;
  result = 37 * result + socket;
  return result % MAX_TABLE_SIZE;
}

int do_accept_get_slot(int socket) {
  int hash = do_accept_hash(socket);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       do_accept_hash_table[i] != NULL
	 && do_accept_hash_table[i]->socket != socket
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void do_accept_wrapper(evutil_socket_t fd, short why, struct do_accept_args *args) {
  do_accept(args->socket);
}

void do_accept_destruct(struct do_accept_args *args) {
  event_free(args->e);
  free(args);
}

void post_do_accept(int socket) {
  int slot = do_accept_get_slot(socket);
  if (slot == -1)
    return;
  if (do_accept_hash_table[slot] == NULL) {
    do_accept_hash_table[slot] = malloc(sizeof(struct do_accept_args));
    do_accept_hash_table[slot]->e =
      event_new(b, socket, EV_READ, (event_callback_fn) do_accept_wrapper, (void *) do_accept_hash_table[slot]);
    do_accept_hash_table[slot]->socket = socket;
    do_accept_hash_table[slot]->destruct = do_accept_destruct;
  }
  event_add(do_accept_hash_table[slot]->e, NULL);
}

void delete_do_accept(int socket) {
  int slot = do_accept_get_slot(socket);
  if (slot != -1 && do_accept_hash_table[slot] != NULL)
    event_del(do_accept_hash_table[slot]->e);
}

int do_read_hash(struct client_state *s) {
  int result = 1;
  result = 37 * result + (int) s;
  result = (result < 0 ? -result : result);
  return result % MAX_TABLE_SIZE;
}

int do_read_get_slot(struct client_state *s) {
  int hash = do_read_hash(s);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       do_read_hash_table[i] != NULL
	 && do_read_hash_table[i]->s != s
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void do_read_wrapper(evutil_socket_t fd, short why, struct do_read_args *args) {
  do_read(args->s);
}

void do_read_destruct(struct do_read_args *args) {
  if (evtimer_pending(args->e, NULL)) {
    delete_do_write(args->s);
    free(args->s);
  }
  event_free(args->e);
  free(args);
}

void post_do_read(struct client_state *s) {
  int slot = do_read_get_slot(s);
  if (slot == -1)
    return;
  if (do_read_hash_table[slot] == NULL) {
    do_read_hash_table[slot] = malloc(sizeof(struct do_read_args));
    do_read_hash_table[slot]->e =
      event_new(b, s->fd, EV_READ, (event_callback_fn) do_read_wrapper, (void *) do_read_hash_table[slot]);
    do_read_hash_table[slot]->s = s;
    do_read_hash_table[slot]->destruct = do_read_destruct;
  }
  event_add(do_read_hash_table[slot]->e, NULL);
}

void delete_do_read(struct client_state *s) {
  int slot = do_read_get_slot(s);
  if (slot != -1 && do_read_hash_table[slot] != NULL)
    event_del(do_read_hash_table[slot]->e);
}

int do_write_hash(struct client_state *s) {
  int result = 1;
  result = 37 * result + (int) s;
  result = (result < 0 ? -result : result);
  return result % MAX_TABLE_SIZE;
}

int do_write_get_slot(struct client_state *s) {
  int hash = do_write_hash(s);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       do_write_hash_table[i] != NULL
	 && do_write_hash_table[i]->s != s
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void do_write_wrapper(evutil_socket_t fd, short why, struct do_write_args *args) {
  do_write(args->s);
}

void do_write_destruct(struct do_write_args *args) {
  if (evtimer_pending(args->e, NULL)) {
    delete_do_read(args->s);
    free(args->s);
  }
  event_free(args->e);
  free(args);
}

void post_do_write(struct client_state *s) {
  int slot = do_write_get_slot(s);
  if (slot == -1)
    return;
  if (do_write_hash_table[slot] == NULL) {
    do_write_hash_table[slot] = malloc(sizeof(struct do_write_args));
    do_write_hash_table[slot]->e =
      event_new(b, s->fd, EV_WRITE, (event_callback_fn) do_write_wrapper, (void *) do_write_hash_table[slot]);
    do_write_hash_table[slot]->s = s;
    do_write_hash_table[slot]->destruct = do_write_destruct;
  }
  event_add(do_write_hash_table[slot]->e, NULL);
}

void delete_do_write(struct client_state *s) {
  int slot = do_write_get_slot(s);
  if (slot != -1 && do_write_hash_table[slot] != NULL)
    event_del(do_write_hash_table[slot]->e);
}

void sigint_handler(evutil_socket_t sig, short why, void *args) {
  printf("\nCleaning up and exiting...\n");
  for (int i = 0; i < MAX_TABLE_SIZE; ++i) {
    DELETE_ENTRY(do_accept_hash_table, i);
    DELETE_ENTRY(do_read_hash_table, i);
    DELETE_ENTRY(do_write_hash_table, i);
  }
  event_free(sigint_event);
}

void async_init() {
  b = event_base_new();
  sigint_event = evsignal_new(b, SIGINT, sigint_handler, NULL);
  evsignal_add(sigint_event, NULL);
}

void async_dispatch_loop() {
  event_base_dispatch(b);
  event_base_free(b);
}

int main(void) {
  async_init();
  _main();
  async_dispatch_loop();
  return 0;
}

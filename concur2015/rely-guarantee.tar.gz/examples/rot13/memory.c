#include <stdlib.h>

#include "memory.h"

struct client_state *malloc_struct_client_state(int bytesize) {
 return malloc(bytesize);
}

void free_struct_client_state(struct client_state *p) {
  free(p);
}

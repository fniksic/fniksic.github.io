#ifndef _MEMORY_H
#define _MEMORY_H

/*** struct client_state memory management ***/

struct client_state;

//@ ghost int heap_status_struct_client_state;

/*@ axiomatic dynamic_struct_client_state {
  @   predicate valid_struct_client_state{L}(struct client_state *p)
  @     reads heap_status_struct_client_state;
  @ }
  @*/

/*@ assigns heap_status_struct_client_state \from heap_status_struct_client_state, bytesize;
  @ assigns \result \from heap_status_struct_client_state, bytesize;
  @ ensures \result != \null;
  @ ensures !valid_struct_client_state{Old}(\result) && valid_struct_client_state(\result);
  @ ensures \forall struct client_state *q;
  @           q != \result ==> (valid_struct_client_state(q) <==> valid_struct_client_state{Old}(q));
  @*/
extern struct client_state *malloc_struct_client_state(int bytesize);

/*@ requires valid_struct_client_state(p);
  @ assigns heap_status_struct_client_state \from heap_status_struct_client_state, p;
  @ ensures !valid_struct_client_state(p);
  @ ensures \forall struct client_state *q;
  @           q != p ==> (valid_struct_client_state(q) <==> valid_struct_client_state{Old}(q));
  @*/
extern void free_struct_client_state(struct client_state *p);

#endif /* _MEMORY_H */

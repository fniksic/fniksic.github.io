#ifndef _ASYNC_H
#define _ASYNC_H

#define MAX_LINE 16384

/* Asynchronous forward declarations. */

struct client_state {
  int fd;
  char buffer[MAX_LINE];
  size_t buffer_used;
  size_t n_written;
  size_t write_upto;
};

extern void do_accept(int socket);
extern void do_read(struct client_state *s);
extern void do_write(struct client_state *s);

//@ ghost int global_pending_do_accept;
//@ ghost int global_pending_do_read;
//@ ghost int global_pending_do_write;

/*@ axiomatic async {
  @   predicate posted_do_accept{L}(int socket)
  @     reads global_pending_do_accept;
  @   predicate posted_do_read{L}(struct client_state *s)
  @     reads global_pending_do_read;
  @   predicate posted_do_write{L}(struct client_state *s)
  @     reads global_pending_do_write;
  @   predicate pending_do_accept{L}(int socket)
  @     reads global_pending_do_accept;
  @   predicate pending_do_read{L}(struct client_state *s)
  @     reads global_pending_do_read;
  @   predicate pending_do_write{L}(struct client_state *s)
  @     reads global_pending_do_write;
  @ }
  @
  @ predicate not_posted_do_accept{L} =
  @   \forall int socket; !posted_do_accept(socket);
  @ predicate not_posted_do_read{L} =
  @   \forall struct client_state *s; !posted_do_read(s);
  @ predicate not_posted_do_write{L} =
  @   \forall struct client_state *s; !posted_do_write(s);
  @ predicate not_pending_do_accept{L}(int socket) =
  @   !pending_do_accept(socket);
  @ predicate not_pending_do_read{L}(struct client_state *s) =
  @   !pending_do_read(s);
  @ predicate not_pending_do_write{L}(struct client_state *s) =
  @   !pending_do_write(s);
  @*/

/*@ assigns global_pending_do_accept;
  @ ensures posted_do_accept(socket);
  @ ensures pending_do_accept(socket);
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (posted_do_accept(socket1) <==> posted_do_accept{Old}(socket1));
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (pending_do_accept(socket1) <==> pending_do_accept{Old}(socket1));
  @*/
extern void post_do_accept(int socket);

/*@ assigns global_pending_do_read;
  @ ensures posted_do_read(s);
  @ ensures pending_do_read(s);
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (posted_do_read(s1) <==> posted_do_read{Old}(s1));
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (pending_do_read(s1) <==> pending_do_read{Old}(s1));
  @*/
extern void post_do_read(struct client_state *s);

/*@ assigns global_pending_do_write;
  @ ensures posted_do_write(s);
  @ ensures pending_do_write(s);
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (posted_do_write(s1) <==> posted_do_write{Old}(s1));
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (pending_do_write(s1) <==> pending_do_write{Old}(s1));
  @*/
extern void post_do_write(struct client_state *s);

/*@ assigns global_pending_do_accept;
  @ ensures !posted_do_accept(socket);
  @ ensures !pending_do_accept(socket);
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (posted_do_accept(socket1) <==> posted_do_accept{Old}(socket1));
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (pending_do_accept(socket1) <==> pending_do_accept{Old}(socket1));
  @*/
extern void delete_do_accept(int socket);

/*@ assigns global_pending_do_read;
  @ ensures !posted_do_read(s);
  @ ensures !pending_do_read(s);
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (posted_do_read(s1) <==> posted_do_read{Old}(s1));
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (pending_do_read(s1) <==> pending_do_read{Old}(s1));
  @*/
extern void delete_do_read(struct client_state *s);

/*@ assigns global_pending_do_write;
  @ ensures !posted_do_write(s);
  @ ensures !pending_do_write(s);
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (posted_do_write(s1) <==> posted_do_write{Old}(s1));
  @ ensures \forall struct client_state *s1;
  @           s != s1 ==>
  @             (pending_do_write(s1) <==> pending_do_write{Old}(s1));
  @*/
extern void delete_do_write(struct client_state *s);

#endif /* _ASYNC_H */

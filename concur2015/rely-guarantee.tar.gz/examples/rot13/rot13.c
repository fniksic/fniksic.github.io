/* For sockaddr_in */
#include <netinet/in.h>
/* For socket functions */
#include <sys/socket.h>
/* For fcntl */
#include <fcntl.h>
/* For htons */
#include <arpa/inet.h>

#include <event2/event.h>

#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>

#include "async.h"
#include "memory.h"

/*@ assigns \nothing;
  @*/
char rot13_char(char c) {
  /* We don't want to use isalpha here; setting the locale would change
   * which characters are considered alphabetical. */
  if ((c >= 'a' && c <= 'm') || (c >= 'A' && c <= 'M'))
    return c + 13;
  else if ((c >= 'n' && c <= 'z') || (c >= 'N' && c <= 'Z'))
    return c - 13;
  else
    return c;
}

/*@ requires precondition:
  @   valid_struct_client_state(s);
  @ requires not_posted_do_read;
  @ requires not_posted_do_write;
  @ requires not_pending_do_read(s);
  @ ensures child_do_read:
  @   \forall struct client_state *s1;
  @     posted_do_read(s1) ==> valid_struct_client_state(s1);
  @ ensures child_do_write:
  @   \forall struct client_state *s1;
  @     posted_do_write(s1) ==> valid_struct_client_state(s1);
  @ ensures rely_do_accept:
  @   \forall int socket;
  @     pending_do_accept{Old}(socket) && pending_do_accept(socket) && \old(\true) ==> \true;
  @ ensures rely_do_read:
  @   \forall struct client_state *s1;
  @     pending_do_read{Old}(s1) && pending_do_read(s1)
  @     && valid_struct_client_state{Old}(s1) ==> valid_struct_client_state(s1);
  @ ensures rely_do_write:
  @   \forall struct client_state *s1;
  @     pending_do_write{Old}(s1) && pending_do_write(s1)
  @     && valid_struct_client_state{Old}(s1) ==> valid_struct_client_state(s1);
  @*/
void do_read(struct client_state *s) {
  char buf[1024];
  int i;
  ssize_t result;
  
  /*@ loop assigns s->buffer_used, s->write_upto, s->buffer[..], i, result, buf[..];
    @ loop assigns global_pending_do_write;
    @ loop invariant \forall struct client_state *arg; posted_do_write(arg) ==> arg == s;
    @*/
  do {
    result = recv(s->fd, buf, sizeof(buf), 0);
    /*@ loop assigns s->buffer_used, s->write_upto, s->buffer[..], i;
      @ loop assigns global_pending_do_write;
      @ loop invariant \forall struct client_state *arg; posted_do_write(arg) ==> arg == s;
      @*/
    for (i = 0; i < result; ++i) {
      if (s->buffer_used < sizeof(s->buffer)){
        s->buffer[s->buffer_used++] = rot13_char(buf[i]);
      }
      if (buf[i] == '\n') {
        s->write_upto = s->buffer_used;
        post_do_write(s);
      }
    }
  } while (result > 0);

  if (result < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
    post_do_read(s);
  }
  else {
    if (result < 0)
      perror("recv");
    delete_do_write(s);
    free_struct_client_state(s);
  }
}

/*@ requires precondition:
  @   valid_struct_client_state(s);
  @ requires not_posted_do_read;
  @ requires not_posted_do_write;
  @ requires not_pending_do_write(s);
  @ ensures child_do_write:
  @   \forall struct client_state *s1;
  @     posted_do_write(s1) ==> valid_struct_client_state(s1);
  @ ensures rely_do_accept:
  @   \forall int socket;
  @     pending_do_accept{Old}(socket) && pending_do_accept(socket) && \old(\true) ==> \true;
  @ ensures rely_do_read:
  @   \forall struct client_state *s1;
  @     pending_do_read{Old}(s1) && pending_do_read(s1)
  @     && valid_struct_client_state{Old}(s1) ==> valid_struct_client_state(s1);
  @ ensures rely_do_write:
  @   \forall struct client_state *s1;
  @     pending_do_write{Old}(s1) && pending_do_write(s1)
  @     && valid_struct_client_state{Old}(s1) ==> valid_struct_client_state(s1);
  @*/
void do_write(struct client_state *s) {
  ssize_t result = 0;

  /*@ loop assigns result, s->n_written;
    @*/
  while (s->n_written < s->write_upto) {
    result = send(s->fd, s->buffer + s->n_written, s->write_upto - s->n_written, 0);
    if (result < 0)
      break;
    s->n_written += result;
  }
  
  if (result < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
    //programmer's assert: I still didn't read everything that do_read gave me
    assert(s->n_written < s->write_upto);
    post_do_write(s);
  } else if (result < 0) {
    perror("send");
    delete_do_read(s);
    free_struct_client_state(s);
  } else {
    // programmer's assert: I read everything do_read gave me
    assert(s->n_written == s->buffer_used);
    s->n_written = s->write_upto = s->buffer_used = 0;
  }
}

/*@ requires not_posted_do_accept;
  @ requires not_posted_do_read;
  @ requires not_pending_do_accept(socket);
  @ ensures child_do_accept:
  @   \forall int socket1;
  @     posted_do_accept(socket1) ==> \true;
  @ ensures child_do_read:
  @   \forall struct client_state *s;
  @     posted_do_read(s) ==> valid_struct_client_state(s);
  @ ensures rely_do_accept:
  @   \forall int socket1;
  @     pending_do_accept{Old}(socket1) && pending_do_accept(socket1) && \old(\true) ==> \true;
  @ ensures rely_do_read:
  @   \forall struct client_state *s;
  @     pending_do_read{Old}(s) && pending_do_read(s)
  @     && valid_struct_client_state{Old}(s) ==> valid_struct_client_state(s);
  @ ensures rely_do_write:
  @   \forall struct client_state *s;
  @     pending_do_write{Old}(s) && pending_do_write(s)
  @     && valid_struct_client_state{Old}(s) ==> valid_struct_client_state(s);
  @*/
void do_accept(int socket) {
  struct sockaddr_storage ss;
  socklen_t slen = sizeof(ss);
  int fd = accept(socket, (struct sockaddr *) &ss, &slen);
  if (fd < 0) { // XXXX eagain??
    perror("accept");
  } else if (fd > FD_SETSIZE) {
    close(fd); // XXX replace all closes with EVUTIL_CLOSESOCKET */
  } else {
    struct client_state *s;
    evutil_make_socket_nonblocking(fd);
    s = malloc_struct_client_state(sizeof(struct client_state));
    s->fd = fd;
    s->buffer_used = s->n_written = s->write_upto = 0;
    // programmer's assert
    //@ assert(valid_struct_client_state(s));
    post_do_read(s);
  }
  post_do_accept(socket);
}

/*@ requires not_posted_do_accept;
  @ ensures child_do_accept:
  @   \forall int socket;
  @     posted_do_accept(socket) ==> \true;
  @*/
void _main(void) {
  int listener;
  struct sockaddr_in sin;

  setvbuf(stdout, NULL, _IONBF, 0);

  sin.sin_family = AF_INET;
  sin.sin_addr.s_addr = 0;
  sin.sin_port = htons(40713);

  listener = socket(AF_INET, SOCK_STREAM, 0);
  evutil_make_socket_nonblocking(listener);

#ifndef WIN32
  {
    int one = 1;
    setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
  }
#endif

  if (bind(listener, (struct sockaddr *) &sin, sizeof(sin)) < 0) {
    perror("bind");
    return;
  }

  if (listen(listener, 16) < 0) {
    perror("listen");
    return;
  }

  post_do_accept(listener);
}

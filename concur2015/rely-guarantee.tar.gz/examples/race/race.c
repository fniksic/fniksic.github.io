#include "async.h"
#include "extra.h"

struct device {
  int owner;
};

struct device dev;

/*@ requires not_posted_do_listen;
  @ requires not_posted_new_client;
  @ requires not_pending_do_listen(socket);
  @ ensures child_guarantee_do_listen:
  @   \forall int socket1;
  @     posted_do_listen(socket1) ==> \true;
  @ ensures child_guarantee_new_client:
  @   \forall int id, int fd;
  @     posted_new_client(id, fd) ==> id > 0;
  @ ensures rely_guarantee_do_listen:
  @   \forall int socket1;
  @     pending_do_listen{Old}(socket1) && pending_do_listen(socket1) && \old(\true) ==> \true;
  @ ensures rely_guarantee_new_client:
  @   \forall int id, int fd;
  @     pending_new_client{Old}(id, fd) && pending_new_client(id, fd) && \old(id > 0) ==> id > 0;
  @ ensures rely_guarantee_write:
  @   \forall int id, int fd;
  @     pending_write{Old}(id, fd) && pending_write(id, fd) &&
  @     \old(id > 0 && dev.owner == id &&
  @          \forall int id1, int fd1; pending_write(id1, fd1) ==> id == id1 && fd == fd1)
  @     ==> id > 0 && dev.owner == id &&
  @         \forall int id1, int fd1; pending_write(id1, fd1) ==> id == id1 && fd == fd1;
  @*/
void do_listen(int socket) {
  int id = new_client_id();
  int fd = accept_connection(socket);
  post_new_client(id, fd);
  post_do_listen(socket);
}

/*@ requires precondition:
  @   id > 0;
  @ requires global_invariant_write:
  @   \forall int id1, int fd1;
  @     pending_write(id1, fd1)
  @     ==> id1 > 0 && dev.owner == id1 &&
  @         \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2;
  @ requires not_posted_new_client;
  @ requires not_posted_write;
  @ requires not_pending_new_client(id, fd);
  @ ensures child_guarantee_new_client:
  @   \forall int id1, int fd1;
  @     posted_new_client(id1, fd1) ==> id1 > 0;
  @ ensures child_guarantee_write:
  @   \forall int id1, int fd1;
  @     posted_write(id1, fd1)
  @     ==> id1 > 0 && dev.owner == id1 &&
  @         \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2;
  @ ensures rely_guarantee_do_listen:
  @   \forall int socket;
  @     pending_do_listen{Old}(socket) && pending_do_listen(socket) && \old(\true) ==> \true;
  @ ensures rely_guarantee_new_client:
  @   \forall int id1, int fd1;
  @     pending_new_client{Old}(id1, fd1) && pending_new_client(id1, fd1) && \old(id1 > 0) ==> id1 > 0;
  @ ensures rely_guarantee_write:
  @   \forall int id1, int fd1;
  @     pending_write{Old}(id1, fd1) && pending_write(id1, fd1) &&
  @     \old(id1 > 0 && dev.owner == id1 &&
  @          \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2)
  @     ==> id1 > 0 && dev.owner == id1 &&
  @         \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2;
  @*/
void new_client(int id, int fd) {
  if (dev.owner != 0)
    post_new_client(id, fd);
  else {
    dev.owner = id;
    post_write(id, fd);
  }
}

/*@ requires precondition:
  @   id > 0 && dev.owner == id &&
  @   \forall int id1, int fd1; pending_write(id1, fd1) ==> id == id1 && fd == fd1;
  @ requires not_posted_write;
  @ requires not_pending_write(id, fd);
  @ ensures child_guarantee_write:
  @   \forall int id1, int fd1;
  @     posted_write(id1, fd1)
  @     ==> id1 > 0 && dev.owner == id1 &&
  @         \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2;
  @ ensures rely_guarantee_do_listen:
  @   \forall int socket;
  @     pending_do_listen{Old}(socket) && pending_do_listen(socket) && \old(\true) ==> \true;
  @ ensures rely_guarantee_new_client:
  @   \forall int id1, int fd1;
  @     pending_new_client{Old}(id1, fd1) && pending_new_client(id1, fd1) && \old(id1 > 0) ==> id1 > 0;
  @ ensures rely_guarantee_write:
  @   \forall int id1, int fd1;
  @     pending_write{Old}(id1, fd1) && pending_write(id1, fd1) &&
  @     \old(id1 > 0 && dev.owner == id1 &&
  @          \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2)
  @     ==> id1 > 0 && dev.owner == id1 &&
  @         \forall int id2, int fd2; pending_write(id2, fd2) ==> id1 == id2 && fd1 == fd2;
  @*/
void write(int id, int fd) {
  if (transfer(id, fd, &dev))
    post_write(id, fd);
  else
    dev.owner = 0;
}

/*@ requires not_posted_do_listen;
  @ ensures child_guarantee_do_listen:
  @   \forall int socket;
  @     posted_do_listen(socket) ==> \true;
  @*/
void _main(void) {
  dev.owner = 0;
  int socket = prepare_socket();
  post_do_listen(socket);
}

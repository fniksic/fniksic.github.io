#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <event2/event.h>
#include "async.h"

#define MAX_TABLE_SIZE 10007

#define DELETE_ENTRY(hash_table, i) do {		\
    if ((hash_table)[(i)] != NULL) {			\
      event_free((hash_table)[(i)]->e);			\
      free((hash_table)[(i)]);				\
    }							\
  } while (0)

extern void _main(void);

struct do_listen_args {
  struct event *e;
  int socket;
} *do_listen_hash_table[MAX_TABLE_SIZE];

struct new_client_args {
  struct event *e;
  int id;
  int fd;
} *new_client_hash_table[MAX_TABLE_SIZE];

struct write_args {
  struct event *e;
  int id;
  int fd;
} *write_hash_table[MAX_TABLE_SIZE];

struct event_base *b;
struct event *sigint_event;

void post(struct event *e, int s) {
  struct timeval tv = { rand() % s, rand() % 1000000 };
  event_add(e, &tv);
}

int do_listen_hash(int socket) {
  int result = 1;
  result = 37 * result + socket;
  return result % MAX_TABLE_SIZE;
}

int do_listen_get_slot(int socket) {
  int hash = do_listen_hash(socket);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       do_listen_hash_table[i] != NULL
	 && do_listen_hash_table[i]->socket != socket
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void do_listen_wrapper(evutil_socket_t fd, short why, struct do_listen_args *args) {
  do_listen(args->socket);
}

void post_do_listen(int socket) {
  int slot = do_listen_get_slot(socket);
  if (slot == -1)
    return;
  if (do_listen_hash_table[slot] == NULL) {
    do_listen_hash_table[slot] = malloc(sizeof(struct do_listen_args));
    do_listen_hash_table[slot]->e =
      evtimer_new(b, (event_callback_fn) do_listen_wrapper, (void *) do_listen_hash_table[slot]);
    do_listen_hash_table[slot]->socket = socket;
  }
  post(do_listen_hash_table[slot]->e, 2);
}

void delete_do_listen(int socket) {
  int slot = do_listen_get_slot(socket);
  if (slot != -1 && do_listen_hash_table[slot] != NULL)
    event_del(do_listen_hash_table[slot]->e);
}

int new_client_hash(int id, int fd) {
  int result = 1;
  result = 37 * result + id;
  result = 37 * result + fd;
  return result % MAX_TABLE_SIZE;
}

int new_client_get_slot(int id, int fd) {
  int hash = new_client_hash(id, fd);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       new_client_hash_table[i] != NULL
	 && !(new_client_hash_table[i]->id == id
	      && new_client_hash_table[i]->fd == fd)
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void new_client_wrapper(evutil_socket_t fd, short why, struct write_args *args) {
  new_client(args->id, args->fd);
}

void post_new_client(int id, int fd) {
  int slot = new_client_get_slot(id, fd);
  if (slot == -1)
    return;
  if (new_client_hash_table[slot] == NULL) {
    new_client_hash_table[slot] = malloc(sizeof(struct new_client_args));
    new_client_hash_table[slot]->e =
      evtimer_new(b, (event_callback_fn) new_client_wrapper, (void *) new_client_hash_table[slot]);
    new_client_hash_table[slot]->id = id;
    new_client_hash_table[slot]->fd = fd;
  }
  post(new_client_hash_table[slot]->e, 1);
}

void delete_new_client(int id, int fd) {
  int slot = new_client_get_slot(id, fd);
  if (slot != -1 && new_client_hash_table[slot] != NULL)
    event_del(new_client_hash_table[slot]->e);
}

int write_hash(int id, int fd) {
  int result = 1;
  result = 37 * result + id;
  result = 37 * result + fd;
  return result % MAX_TABLE_SIZE;
}

int write_get_slot(int id, int fd) {
  int hash = write_hash(id, fd);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       write_hash_table[i] != NULL
	 && !(write_hash_table[i]->id == id
	      && write_hash_table[i]->fd == fd)
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void write_wrapper(evutil_socket_t fd, short why, struct new_client_args *args) {
  write(args->id, args->fd);
}

void post_write(int id, int fd) {
  int slot = write_get_slot(id, fd);
  if (slot == -1)
    return;
  if (write_hash_table[slot] == NULL) {
    write_hash_table[slot] = malloc(sizeof(struct write_args));
    write_hash_table[slot]->e =
      evtimer_new(b, (event_callback_fn) write_wrapper, (void *) write_hash_table[slot]);
    write_hash_table[slot]->id = id;
    write_hash_table[slot]->fd = fd;
  }
  post(write_hash_table[slot]->e, 3);
}

void delete_write(int id, int fd) {
  int slot = write_get_slot(id, fd);
  if (slot != -1 && write_hash_table[slot] != NULL)
    event_del(write_hash_table[slot]->e);
}

void sigint_handler(evutil_socket_t sig, short why, void *args) {
  printf("\nCleaning up and exiting...\n");
  for (int i = 0; i < MAX_TABLE_SIZE; ++i) {
    DELETE_ENTRY(do_listen_hash_table, i);
    DELETE_ENTRY(new_client_hash_table, i);
    DELETE_ENTRY(write_hash_table, i);
  }
  event_free(sigint_event);
}

void async_init() {
  b = event_base_new();
  srand(time(NULL));
  sigint_event = evsignal_new(b, SIGINT, sigint_handler, NULL);
  evsignal_add(sigint_event, NULL);
}

void async_dispatch_loop() {
  event_base_dispatch(b);
  event_base_free(b);
}

int main(void) {
  async_init();
  _main();
  async_dispatch_loop();
  return 0;
}

#ifndef _ASYNC_H
#define _ASYNC_H

/* Asynchronous forward declarations */

extern void do_listen(int socket);
extern void new_client(int id, int fd);
extern void write(int id, int fd);

//@ ghost int global_pending_do_listen;
//@ ghost int global_pending_new_client;
//@ ghost int global_pending_write;

/*@ axiomatic async {
  @   predicate posted_do_listen{L}(int socket) reads global_pending_do_listen;
  @   predicate pending_do_listen{L}(int socket) reads global_pending_do_listen;
  @   predicate posted_new_client{L}(int id, int fd) reads global_pending_new_client;
  @   predicate pending_new_client{L}(int id, int fd) reads global_pending_new_client;
  @   predicate posted_write{L}(int id, int fd) reads global_pending_write;
  @   predicate pending_write{L}(int id, int fd) reads global_pending_write;
  @ }
  @
  @ predicate not_posted_do_listen{L} = \forall int socket; !posted_do_listen(socket);
  @ predicate not_pending_do_listen{L}(int socket) = !pending_do_listen(socket);
  @ predicate not_posted_new_client{L} = \forall int id, int fd; !posted_new_client(id, fd);
  @ predicate not_pending_new_client{L}(int id, int fd) = !pending_new_client(id, fd);
  @ predicate not_posted_write{L} = \forall int id, int fd; !posted_write(id, fd);
  @ predicate not_pending_write{L}(int id, int fd) = !pending_write(id, fd);
  @*/

/*@ assigns global_pending_do_listen;
  @ ensures posted_do_listen(socket);
  @ ensures pending_do_listen(socket);
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (posted_do_listen(socket1) <==> posted_do_listen{Old}(socket1));
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (pending_do_listen(socket1) <==> pending_do_listen{Old}(socket1));
  @*/
extern void post_do_listen(int socket);

/*@ assigns global_pending_do_listen;
  @ ensures !posted_do_listen(socket);
  @ ensures !pending_do_listen(socket);
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (posted_do_listen(socket1) <==> posted_do_listen{Old}(socket1));
  @ ensures \forall int socket1;
  @           socket != socket1 ==>
  @             (pending_do_listen(socket1) <==> pending_do_listen{Old}(socket1));
  @*/
extern void delete_do_listen(int socket);

/*@ assigns global_pending_new_client;
  @ ensures posted_new_client(id, fd);
  @ ensures pending_new_client(id, fd);
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (posted_new_client(id1, fd1) <==> posted_new_client{Old}(id1, fd1));
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (pending_new_client(id1, fd1) <==> pending_new_client{Old}(id1, fd1));
  @*/
extern void post_new_client(int id, int fd);

/*@ assigns global_pending_new_client;
  @ ensures !posted_new_client(id, fd);
  @ ensures !pending_new_client(id, fd);
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (posted_new_client(id1, fd1) <==> posted_new_client{Old}(id1, fd1));
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (pending_new_client(id1, fd1) <==> pending_new_client{Old}(id1, fd1));
  @*/
extern void delete_new_client(int id, int fd);

/*@ assigns global_pending_write;
  @ ensures posted_write(id, fd);
  @ ensures pending_write(id, fd);
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (posted_write(id1, fd1) <==> posted_write{Old}(id1, fd1));
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (pending_write(id1, fd1) <==> pending_write{Old}(id1, fd1));
  @*/
extern void post_write(int id, int fd);

/*@ assigns global_pending_write;
  @ ensures !posted_write(id, fd);
  @ ensures !pending_write(id, fd);
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (posted_write(id1, fd1) <==> posted_write{Old}(id1, fd1));
  @ ensures \forall int id1, int fd1;
  @           !(id == id1 && fd == fd1) ==>
  @             (pending_write(id1, fd1) <==> pending_write{Old}(id1, fd1));
  @*/
extern void delete_write(int id, int fd);

#endif /* _ASYNC_H */

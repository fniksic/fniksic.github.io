#ifndef _EXTRA_H
#define _EXTRA_H

//@ ghost int id_status;

/*@ axiomatic id_uniqueness {
  @   predicate spent{L}(int id) reads id_status;
  @ }
  @
  @ predicate fresh{L1, L2}(int id) =
  @   !spent{L1}(id) && spent{L2}(id) &&
  @   \forall int id1; spent{L1}(id1) ==> spent{L2}(id1);
  @*/

struct device;

/*@ assigns id_status;
  @ ensures \result > 0;
  @ ensures fresh{Old, Post}(\result);
  @*/
extern int new_client_id();

//@ assigns \nothing;
extern int prepare_socket();

//@ assigns \nothing;
extern int accept_connection(int socket);

/*@ assigns \nothing;
  @ ensures \result >= 0;
  @*/
extern int transfer(int id, int fd, struct device *dev);

#endif /* _EXTRA_H */

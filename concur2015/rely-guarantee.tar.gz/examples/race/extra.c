#include <stdio.h>
#include <stdlib.h>
#include "extra.h"

int transfer(int id, int fd, struct device *dev) {
  const char *msg_ending[] = { "Finished.", "More to come..." };
  const int more = rand() % 2;
  printf("[Client %d] Transferred data to the device. %s\n", id, msg_ending[more]);
  return more;
}

int new_client_id() {
  static int curr_id = 0;
  return ++curr_id;
}

int prepare_socket() {
  return 0; // Irrelevant.
}

int accept_connection(int socket) {
  return 0; // Irrelevant.
}

#ifndef _ASYNC_H
#define _ASYNC_H

/* Asynchronous forward declarations */

struct request;

extern void add_reqs();
extern void process_reqs();
extern void client(struct request *r);

//@ ghost int global_pending_add_reqs;
//@ ghost int global_pending_process_reqs;
//@ ghost int global_pending_client;

/*@ axiomatic async {
  @   predicate posted_add_reqs{L} reads global_pending_add_reqs;
  @   predicate pending_add_reqs{L} reads global_pending_add_reqs;
  @   predicate posted_process_reqs{L} reads global_pending_process_reqs;
  @   predicate pending_process_reqs{L} reads global_pending_process_reqs;
  @   predicate posted_client{L}(struct request *r) reads global_pending_client;
  @   predicate pending_client{L}(struct request *r) reads global_pending_client;
  @ }
  @ 
  @ predicate not_posted_add_reqs{L} = !posted_add_reqs;
  @ predicate not_pending_add_reqs{L} = !pending_add_reqs;
  @ predicate not_posted_process_reqs{L} = !posted_process_reqs;
  @ predicate not_pending_process_reqs{L} = !pending_process_reqs;
  @ predicate not_posted_client{L} = \forall struct request *r; !posted_client(r);
  @ predicate not_pending_client{L}(struct request *r) = !pending_client(r);
  @*/

/*@ assigns global_pending_add_reqs;
  @ ensures posted_add_reqs;
  @ ensures pending_add_reqs;
  @*/
extern void post_add_reqs();

/*@ assigns global_pending_add_reqs;
  @ ensures !posted_add_reqs;
  @ ensures !pending_add_reqs;
  @*/
extern void delete_add_reqs();

/*@ assigns global_pending_process_reqs;
  @ ensures posted_process_reqs;
  @ ensures pending_process_reqs;
  @*/
extern void post_process_reqs();

/*@ assigns global_pending_process_reqs;
  @ ensures !posted_process_reqs;
  @ ensures !pending_process_reqs;
  @*/
extern void delete_process_reqs();

/*@ assigns global_pending_client;
  @ ensures posted_client(r);
  @ ensures pending_client(r);
  @ ensures \forall struct request *r1;
  @           r != r1 ==>
  @             (posted_client(r1) <==> posted_client{Old}(r1));
  @ ensures \forall struct request *r1;
  @           r != r1 ==>
  @             (pending_client(r1) <==> pending_client{Old}(r1));
  @*/
extern void post_client(struct request *r);

/*@ assigns global_pending_client;
  @ ensures !posted_client(r);
  @ ensures !pending_client(r);
  @ ensures \forall struct request *r1;
  @           r != r1 ==>
  @             (posted_client(r1) <==> posted_client{Old}(r1));
  @ ensures \forall struct request *r1;
  @           r != r1 ==>
  @             (pending_client(r1) <==> pending_client{Old}(r1));
  @*/
extern void delete_client(struct request *r);

#endif /* _ASYNC_H */

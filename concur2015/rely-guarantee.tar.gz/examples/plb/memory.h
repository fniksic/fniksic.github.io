#ifndef _MEMORY_H
#define _MEMORY_H

/*** struct request memory management ***/

struct request;

//@ ghost int heap_status_struct_request;

/*@ axiomatic dynamic_struct_request {
  @   predicate valid_struct_request{L}(struct request *p)
  @     reads heap_status_struct_request;
  @ }
  @*/

/*@ assigns heap_status_struct_request \from heap_status_struct_request, bytesize;
  @ assigns \result \from heap_status_struct_request, bytesize;
  @ ensures \result != \null;
  @ ensures !valid_struct_request{Old}(\result) && valid_struct_request(\result);
  @ ensures \forall struct request *q;
  @           q != \result ==> (valid_struct_request(q) <==> valid_struct_request{Old}(q));
  @*/
extern struct request *malloc_struct_request(int bytesize);

/*@ requires valid_struct_request(p);
  @ assigns heap_status_struct_request \from heap_status_struct_request, p;
  @ ensures !valid_struct_request(p);
  @ ensures \forall struct request *q;
  @           q != p ==> (valid_struct_request(q) <==> valid_struct_request{Old}(q));
  @*/
extern void free_struct_request(struct request *p);

#endif /* _MEMORY_H */

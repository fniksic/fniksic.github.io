#include <stdlib.h>

#include "memory.h"

struct request *malloc_struct_request(int bytesize) {
  return malloc(bytesize);
}

void free_struct_request(struct request *p) {
  free(p);
}


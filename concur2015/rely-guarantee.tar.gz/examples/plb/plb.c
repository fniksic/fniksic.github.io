#include <stdio.h>
#include <stdlib.h>

#include "async.h"
#include "memory.h"

struct request {
  struct request *next;
};

struct request *reqs;

/*@ requires not_posted_add_reqs;
  @ requires not_pending_add_reqs;
  @ ensures child_add_reqs:
  @   posted_add_reqs ==> \true;
  @ ensures rely_add_reqs:
  @   pending_add_reqs{Old} && pending_add_reqs && \old(\true) ==> \true;
  @ ensures rely_process_reqs:
  @   pending_process_reqs{Old} && pending_process_reqs && \old(\true) ==> \true;
  @ ensures rely_client:
  @   \forall struct request *r;
  @     pending_client{Old}(r) && pending_client(r) && \old(r != \null) ==> r != \null;
  @*/
void add_reqs() {
  struct request *new_req = malloc_struct_request(sizeof(struct request));
  //printf("[add_reqs] Adding a new request.\n");
  new_req->next = reqs;
  reqs = new_req;
  post_add_reqs();
}

/*@ requires not_posted_process_reqs;
  @ requires not_posted_client;
  @ requires not_pending_process_reqs;
  @ ensures child_process_reqs:
  @   posted_process_reqs ==> \true;
  @ ensures child_client:
  @   \forall struct request *r;
  @     posted_client(r) ==> r != \null;
  @ ensures rely_add_reqs:
  @   pending_add_reqs{Old} && pending_add_reqs && \old(\true) ==> \true;
  @ ensures rely_process_reqs:
  @   pending_process_reqs{Old} && pending_process_reqs && \old(\true) ==> \true;
  @ ensures rely_client:
  @   \forall struct request *r;
  @     pending_client{Old}(r) && pending_client(r) && \old(r != \null) ==> r != \null;
  @*/
void process_reqs() {
  /*@ loop invariant
    @   \forall struct request *r;
    @     posted_client(r) ==> r != \null;
    @*/
  while (reqs != NULL) {
    //printf("[process_reqs] Posting client.\n");
    post_client(reqs);
    reqs = reqs->next;
  }
  post_process_reqs();
}

/*@ requires precondition:
  @   r != \null;
  @ requires not_pending_client(r);
  @ ensures rely_add_reqs:
  @   pending_add_reqs{Old} && pending_add_reqs && \old(\true) ==> \true;
  @ ensures rely_process_reqs:
  @   pending_process_reqs{Old} && pending_process_reqs && \old(\true) ==> \true;
  @ ensures rely_client:
  @   \forall struct request *r1;
  @     pending_client{Old}(r1) && pending_client(r1) && \old(r1 != \null) ==> r1 != \null;
  @*/
void client(struct request *r) {
  //printf("[client] Processing a request.\n");  
  free_struct_request(r);
}

/*@ requires not_posted_add_reqs;
  @ requires not_posted_process_reqs;
  @*/
void _main(void) {
  reqs = NULL;
  post_add_reqs();
  post_process_reqs();
}

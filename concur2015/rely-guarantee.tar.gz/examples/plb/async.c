#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <sys/time.h>
#include <event2/event.h>
#include "async.h"

#define MAX_TABLE_SIZE 10007

#define DELETE_ENTRY(hash_table, i) do {		\
    if ((hash_table)[(i)] != NULL) {			\
      (hash_table)[(i)]->destruct((hash_table)[(i)]);	\
    }							\
  } while (0)

extern void _main(void);

struct add_reqs_args {
  struct event *e;
  void (*destruct)(struct add_reqs_args *);
} *add_reqs_hash_table[MAX_TABLE_SIZE];

struct process_reqs_args {
  struct event *e;
  void (*destruct)(struct process_reqs_args *);
} *process_reqs_hash_table[MAX_TABLE_SIZE];

struct client_args {
  struct event *e;
  struct request *r;
  void (*destruct)(struct client_args *);
} *client_hash_table[MAX_TABLE_SIZE];

struct event_base *b;
struct event *sigint_event;

void post(struct event *e, int s) {
  struct timeval tv = { rand() % s, rand() % 1000000 };
  event_add(e, &tv);
}

int add_reqs_hash() {
  int result = 1;
  return result % MAX_TABLE_SIZE;
}

int add_reqs_get_slot() {
  int hash = add_reqs_hash();
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       add_reqs_hash_table[i] != NULL
	 && 0
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void add_reqs_wrapper(evutil_socket_t fd, short why, struct add_reqs_args *args) {
  add_reqs();
}

void add_reqs_destruct(struct add_reqs_args *args) {
  event_free(args->e);
  free(args);
}

void post_add_reqs() {
  int slot = add_reqs_get_slot();
  if (slot == -1)
    return;
  if (add_reqs_hash_table[slot] == NULL) {
    add_reqs_hash_table[slot] = malloc(sizeof(struct add_reqs_args));
    add_reqs_hash_table[slot]->e =
      evtimer_new(b, (event_callback_fn) add_reqs_wrapper, (void *) add_reqs_hash_table[slot]);
    add_reqs_hash_table[slot]->destruct = add_reqs_destruct;
  }
  post(add_reqs_hash_table[slot]->e, 2);
}

void delete_add_reqs() {
  int slot = add_reqs_get_slot();
  if (slot != -1 && add_reqs_hash_table[slot] != NULL)
    event_del(add_reqs_hash_table[slot]->e);
}

int process_reqs_hash() {
  int result = 1;
  return result % MAX_TABLE_SIZE;
}

int process_reqs_get_slot() {
  int hash = process_reqs_hash();
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       process_reqs_hash_table[i] != NULL
	 && 0
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void process_reqs_wrapper(evutil_socket_t fd, short why, struct process_reqs_args *args) {
  process_reqs();
}

void process_reqs_destruct(struct process_reqs_args *args) {
  event_free(args->e);
  free(args);
}

void post_process_reqs() {
  int slot = process_reqs_get_slot();
  if (slot == -1)
    return;
  if (process_reqs_hash_table[slot] == NULL) {
    process_reqs_hash_table[slot] = malloc(sizeof(struct process_reqs_args));
    process_reqs_hash_table[slot]->e =
      evtimer_new(b, (event_callback_fn) process_reqs_wrapper, (void *) process_reqs_hash_table[slot]);
    process_reqs_hash_table[slot]->destruct = process_reqs_destruct;
  }
  post(process_reqs_hash_table[slot]->e, 5);
}

void delete_process_reqs() {
  int slot = process_reqs_get_slot();
  if (slot != -1 && process_reqs_hash_table[slot] != NULL)
    event_del(process_reqs_hash_table[slot]->e);
}

int client_hash(struct request *r) {
  int result = 1;
  result = 37 * result + (int) r;
  result = (result < 0 ? -result : result);
  return result % MAX_TABLE_SIZE;
}

int client_get_slot(struct request *r) {
  int hash = client_hash(r);
  int i;
  for (i = (hash + 1) % MAX_TABLE_SIZE;
       client_hash_table[i] != NULL
	 && client_hash_table[i]->r != r
	 && i != hash;
       i = (i + 1) % MAX_TABLE_SIZE);
  return i == hash ? -1 : i;
}

void client_wrapper(evutil_socket_t fd, short why, struct client_args *args) {
  client(args->r);
}

void client_destruct(struct client_args *args) {
  if (evtimer_pending(args->e, NULL))
    free(args->r);
  event_free(args->e);
  free(args);
}

void post_client(struct request *r) {
  int slot = client_get_slot(r);
  if (slot == -1)
    return;
  if (client_hash_table[slot] == NULL) {
    client_hash_table[slot] = malloc(sizeof(struct client_args));
    client_hash_table[slot]->e =
      evtimer_new(b, (event_callback_fn) client_wrapper, (void *) client_hash_table[slot]);
    client_hash_table[slot]->r = r;
    client_hash_table[slot]->destruct = client_destruct;
  }
  post(client_hash_table[slot]->e, 1);
}

void delete_client(struct request *r) {
  int slot = client_get_slot(r);
  if (slot != -1 && client_hash_table[slot] != NULL)
    event_del(client_hash_table[slot]->e);
}

void sigint_handler(evutil_socket_t sig, short why, void *args) {
  printf("\nCleaning up and exiting...\n");
  for (int i = 0; i < MAX_TABLE_SIZE; ++i) {
    DELETE_ENTRY(add_reqs_hash_table, i);
    DELETE_ENTRY(process_reqs_hash_table, i);
    DELETE_ENTRY(client_hash_table, i);
  }
  event_free(sigint_event);
}

void async_init() {
  b = event_base_new();
  srand(time(NULL));
  sigint_event = evsignal_new(b, SIGINT, sigint_handler, NULL);
  evsignal_add(sigint_event, NULL);
}

void async_dispatch_loop() {
  event_base_dispatch(b);
  event_base_free(b);
}

int main(void) {
  async_init();
  _main();
  async_dispatch_loop();
  return 0;
}
